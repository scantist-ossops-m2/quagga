extern int in_cksum(void *, int);
